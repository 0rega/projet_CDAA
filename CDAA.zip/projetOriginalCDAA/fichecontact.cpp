#include "fichecontact.h"
#include "contact.h"
#include "ui_fichecontact.h"

FicheContact::FicheContact(QWidget *parent) : QMainWindow(parent),
    ui(new Ui::FicheContact)
{
    ui->setupUi(this);
    dbPath = "C:/Users/bello/Downloads/projetOriginalCDAA/base.sqlite";


    connect(ui->bValidate , SIGNAL(clicked()) , this , SLOT(on_bValidate_clicked())) ;

}

FicheContact::~FicheContact()
{
    delete ui;
}

void FicheContact::on_bValidate_clicked()
{
    if(f == true){
    db = QSqlDatabase::addDatabase("QSQLITE") ;
    QSqlQuery query ;
    qDebug() << "affiche BD" ;
    db.setDatabaseName(dbPath) ;
    if(!db.open()){
        qDebug() << "Pas de connexion  à la BDD"  ;
    }
    else{
           qDebug() <<"Connexion BDD ok ! " ;
           string s ;
           query.prepare("INSERT INTO Contact (Nom, Prenom ,Entreprise, Mail, Telephone )"
                         "VALUES (?, ?, ?, ?, ?)");
           query.addBindValue(ui->tbNom->text());
           query.addBindValue(ui->tbPrenom->text());
           query.addBindValue(ui->tbEntreprise->text());
           query.addBindValue(ui->tbEmail->text()) ;
           query.addBindValue(ui->tbTel->text()) ;
           /*query.addBindValue(plocate) ;
           s = to_string(nsx->tm_mday) + "/" + to_string(nsx->tm_mon+1) + "/" + to_string(nsx->tm_year+1900) + " " +to_string(nsx->tm_hour) + ":" + to_string(nsx->tm_min) + ":" + to_string(nsx->tm_sec ) ;
           QString x = QString::fromStdString(s) ;
           query.addBindValue(x);
           query.addBindValue(contenuinteraction) ;
           query.addBindValue(contenutodo) ;*/
           if(!query.exec()){
               qDebug() << "Impossible d'executer la requête" ;

           }
           else{
               qDebug() << "Requete OK" ;
               qDebug() << "Ajout reussit" ;

           }
        }
    db.close() ;
    emit actualiser() ;
    this->close() ;
    }
    else {
        db = QSqlDatabase::addDatabase("QSQLITE") ;
        QSqlQuery query ;
        db.setDatabaseName(dbPath) ;
        if(!db.open()) {
            qDebug() << "Pas de connexion à la BDD" ;
        }
        else
        {
            qDebug() << "Connexion à la BDD ok ! " ;
            query.prepare("UPDATE Contact set Nom = ? , Prenom = ? , Entreprise = ? , Mail = ? , Telephone = ? where idContact = ?") ;
            query.addBindValue(ui->tbNom->text()) ;
            query.addBindValue(ui->tbPrenom->text()) ;
            query.addBindValue(ui->tbEntreprise->text()) ;
            query.addBindValue(ui->tbEmail->text()) ;
            query.addBindValue(ui->tbTel->text()) ;
            query.addBindValue(id) ;
            if(!query.exec()){
                qDebug() << "Erreur de requete dans la base de donnée " ;
            }
            else{
                qDebug() << "Requete OK" ;
                qDebug() << "Modification reussit " ;
            }

        }
    }
}

void FicheContact::openajout(){
    f = true ;
}

void FicheContact::openmodification(QString &l){
    f = false ;
    id = l ;
}

void FicheContact::on_bCanceled_clicked()
{
    this->close() ;
}


