#ifndef FICHECONTACTDIALOG_H
#define FICHECONTACTDIALOG_H

#include <QDialog>
#include <QSqlDatabase>
#include <QDebug>
#include <QSqlQuery>
#include "contact.h"
#include <QFileDialog>
#include <sstream>

namespace Ui {
class FicheContactDialog;
}

class FicheContactDialog : public QDialog
{
    Q_OBJECT

public:
    explicit FicheContactDialog(QWidget *parent = nullptr);
    ~FicheContactDialog();
    void setInfos(const Contact &, const QString &);
    void modifier();
    void ajouter();

private slots:
    void on_bValidate_clicked();

    void on_bCanceled_clicked();

    void on_bAjout_photo_clicked() ;

    void on_tbTel_textChanged(const QString &arg1);

private:
    Ui::FicheContactDialog *ui;
    QSqlDatabase db;
    QString dbPath;
    QString plocate ;
    QString id;
};

#endif // FICHECONTACTDIALOG_H
