#include "fichecontact.h"
#include "contact.h"
#include "ui_fichecontact.h"

FicheContact::FicheContact(QWidget *parent) : QMainWindow(parent),
    ui(new Ui::FicheContact)
{
    ui->setupUi(this);
    dbPath = "D:/GitHub/projet_CDAA/projetOriginalCDAA/base.sqlite";


    //connect(ui->bValidate , SIGNAL(clicked()) , this , SLOT(on_bValidate_clicked())) ;
    connect(ui->bAjout_photo ,  SIGNAL(clicked()) , this, SLOT(ajouterx_UP())) ;
}

FicheContact::~FicheContact()
{
    delete ui;
}


string s ;



void FicheContact::on_bValidate_clicked()
{
    /*
    Contact c ;
    list<int> t ;
    t.push_back(stoi(QString::fromStdString(ui->tbTel->text()))) ;
    c.setNom(QString::fromStdString(ui->tbNom->text())) ;
    c.setPrenom(QString::fromStdString(ui->tbPrenom->text())) ;
    c.setEntreprise(QString::fromStdString(ui->tbEntreprise->text())) ;
    c.setMail(QString::fromStdString(ui->tbEmail->text())) ;
    c.setTelephone(t) ;
    c.setUriPhoto(plocate) ;
    dbx.insertContact(c) ;
    */
    db = QSqlDatabase::addDatabase("QSQLITE") ;
    QSqlQuery query ;

    qDebug() << "affiche BD" ;
    db.setDatabaseName(dbPath) ;
    if(!db.open()){
        qDebug() << "Pas de connexion  à la BDD"  ;
    }
    else{
           qDebug() <<"Connexion BDD ok ! " ;
           string s ;
           time_t timestamp = time( NULL );
           struct tm * nsx = localtime( & timestamp );

           query.prepare("INSERT INTO Contact (Nom, Prenom ,Entreprise, Mail, Telephone , Interaction , photo,  Date_de_creation )"
                         "VALUES (?, ?, ?, ?, ? , ? , ?, ?)");
           query.addBindValue(ui->tbNom->text());
           query.addBindValue(ui->tbPrenom->text());
           query.addBindValue(ui->tbEntreprise->text());
           query.addBindValue(ui->tbEmail->text()) ;
           query.addBindValue(ui->tbTel->text()) ;
           query.addBindValue(ui->tbInteraction->text()) ;   
           query.addBindValue(plocate) ;
           s = to_string(nsx->tm_mday) + "/" + to_string(nsx->tm_mon+1) + "/" + to_string(nsx->tm_year+1900) + " " +to_string(nsx->tm_hour) + ":" + to_string(nsx->tm_min) + ":" + to_string(nsx->tm_sec ) ;
           QString x = QString::fromStdString(s) ;
           query.addBindValue(x);
           //query.addBindValue(contenuinteraction) ;
           //query.addBindValue(contenutodo) ;
           if(!query.exec()){
               qDebug() << "Impossible d'executer la requête" ;

           }
           else{
               qDebug() << "Requete OK" ;
               qDebug() << "Ajout reussit" ;

           }
        }
    db.close() ;
    emit actualiser() ;
    this->close() ;
}

void FicheContact::ajouterx_UP(){
    qDebug()  << "Ajout de photo" ;

    QString filename = QFileDialog::getOpenFileName(this , tr("Choisir") , "" , tr("Images(*.png *.jpg *.jpeg *.bmp *.gif)")) ;
    if(QString::compare(filename, QString()) != 0){
        QImage image ;
        bool valide = image.load(filename) ;
        if(valide){
            image = image.scaledToWidth(50 , Qt::SmoothTransformation);
            ui->lbAffichePhoto->setPixmap(QPixmap::fromImage(image)) ;
        }
        else{
            // erreur de la mise en photo ;
        }

    }
    plocate = filename ;
}

void FicheContact::openajout(){
    f = true ;
}

void FicheContact::openmodification(QString &l){
    f = false ;
    id = l ;

    //Modification code
    /*
    db = QSqlDatabase::addDatabase("QSQLITE") ;
    QSqlQuery query ;
    db.setDatabaseName(dbPath) ;
    if(!db.open()) {
        qDebug() << "Pas de connexion à la BDD" ;
    }
    else
    {
        qDebug() << "Connexion à la BDD ok ! " ;
        query.prepare("UPDATE Contact set Nom = ? , Prenom = ? , Entreprise = ? , Mail = ? , Telephone = ? where idContact = ?") ;
        query.addBindValue(ui->tbNom->text()) ;
        query.addBindValue(ui->tbPrenom->text()) ;
        query.addBindValue(ui->tbEntreprise->text()) ;
        query.addBindValue(ui->tbEmail->text()) ;
        query.addBindValue(ui->tbTel->text()) ;
        query.addBindValue(id) ;
        if(!query.exec()){
            qDebug() << "Erreur de requete dans la base de donnée " ;
        }
        else{
            qDebug() << "Requete OK" ;
            qDebug() << "Modification reussit " ;
        }

    }
    */
}

void FicheContact::on_bCanceled_clicked()
{
    this->close() ;
}


