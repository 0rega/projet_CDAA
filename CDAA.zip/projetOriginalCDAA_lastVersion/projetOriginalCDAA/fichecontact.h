#ifndef FICHECONTACT_H
#define FICHECONTACT_H

#include <QMainWindow>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtDebug>
#include <QFileDialog>

namespace Ui {
class FicheContact;
}

class FicheContact : public QMainWindow
{
    Q_OBJECT

public:
    explicit FicheContact(QWidget *parent = nullptr);
    ~FicheContact();

private slots:
    void on_bValidate_clicked();
    void openajout() ;
    void openmodification(QString&) ;
    void on_bCanceled_clicked();
    void ajouterx_UP() ;

signals:
    void actualiser() ;

private:
    QSqlDatabase db;
    QString dbPath;
    QString plocate ;
    Ui::FicheContact *ui;
    bool f ;
    QString id;

};

#endif // FICHECONTACT_H
