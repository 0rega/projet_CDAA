#include "mainwindow.h"

#include <QApplication>
#include <QLocale>
#include <QTranslator>
#include "contact.h"
#include "basededonne.h"


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QTranslator translator;
    const QStringList uiLanguages = QLocale::system().uiLanguages();
    for (const QString &locale : uiLanguages) {
        const QString baseName = "projetOriginalCDAA_" + QLocale(locale).name();
        if (translator.load(":/i18n/" + baseName)) {
            a.installTranslator(&translator);
            break;
        }
    }
    MainWindow w;
    w.show();
    QObject::connect(&w , SIGNAL(signalcontact(GestionContact&)) , &w, SLOT(show_in_list(GestionContact&))) ;
    //QObject::connect(&w , SIGNAL(listqstring(QString&)) , &m , SLOT(add_in_list(QString&))) ;
    return a.exec()  ;
}
