#include "jsonexport.h"

JsonExport::JsonExport(QObject *parent) : QObject(parent)
{

}
