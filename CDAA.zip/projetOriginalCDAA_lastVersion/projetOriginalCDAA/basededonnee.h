#ifndef BASEDEDONNEE_H
#define BASEDEDONNEE_H

#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QDebug>
#include <QObject>

class BaseDeDonnee : public QObject
{
    Q_OBJECT
public:
    explicit BaseDeDonnee(QObject *parent = nullptr);

    void connexionBDD() ;

public slots:
    void deleteContact(const QString &);

private:
    QSqlDatabase db ;
    QString dbPath;


};

#endif // BASEDEDONNEE_H
