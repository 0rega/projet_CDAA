#ifndef JSONEXPORT_H
#define JSONEXPORT_H

#include <QObject>
#include <QJsonValue>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonDocument>
#include <QDebug>


class JsonExport : public QObject
{
    Q_OBJECT
public:
    explicit JsonExport(QObject *parent = nullptr);


};

#endif // JSONEXPORT_H
