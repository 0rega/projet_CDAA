#ifndef LISTINTERACTIONDIALOG_H
#define LISTINTERACTIONDIALOG_H

#include <QDialog>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QDebug>

namespace Ui {
class ListInteractionDialog;
}

class ListInteractionDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ListInteractionDialog(QWidget *parent = nullptr);
    ~ListInteractionDialog();
    void afficheInteraction();
    void setId(const QString &);

private slots:
    void on_bClose_clicked();

private:
    Ui::ListInteractionDialog *ui;
    QString idC;
    QString dbPath;
    QSqlDatabase db ;
};

#endif // LISTINTERACTIONDIALOG_H
