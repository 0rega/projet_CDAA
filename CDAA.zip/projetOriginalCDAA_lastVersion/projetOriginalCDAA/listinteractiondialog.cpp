#include "listinteractiondialog.h"
#include "ui_listinteractiondialog.h"

/** Constructeur
 * @brief ListInteractionDialog::ListInteractionDialog
 * @param parent
 */
ListInteractionDialog::ListInteractionDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ListInteractionDialog)
{
    dbPath = "C:/Users/bello/Downloads/projetOriginalCDAA_lastVersion/projetOriginalCDAA/base.sqlite";
    ui->setupUi(this);
}

/** Destructeur
 * @brief ListInteractionDialog::~ListInteractionDialog
 */
ListInteractionDialog::~ListInteractionDialog()
{
    delete ui;
}

/** Affichage liste interaction
 * @brief ListInteractionDialog::afficheInteraction
 */
void ListInteractionDialog::afficheInteraction()
{
    ui->listInteraction->setRowCount(0);
    db = QSqlDatabase::addDatabase("QSQLITE") ;
    db.setDatabaseName(dbPath) ;
    QSqlQuery query ;
    if(!db.open()){
        qDebug() << "Impossible de la connexion de la base de donnée "  ;
    }
    else{
        qDebug() << "Connexion ok  de la BDD" ;
        query.prepare("SELECT * FROM Interaction") ;
        if(!query.exec()){
            qDebug() << "Impossible d'executer la requete " ;
        }
        else{
            QString s ;
            qDebug() << "Requete reussit" ;
            //qDebug()<< i ;

            //qDebug() << nbrow ;
            int nbcol = 3 ;
            //ui->ListContacts->setRowCount(nbrow) ;
            ui->listInteraction->setColumnCount(nbcol) ;
            QStringList hlabels ;
            hlabels << "idInteraction" << "Contenu" << "Date";
            ui->listInteraction->setHorizontalHeaderLabels(hlabels);
            int i = 0;
            while(query.next()){
                ui->listInteraction->insertRow( ui->listInteraction->rowCount() );
                QTableWidgetItem *item ;
                for(int j = 0 ; j < nbcol ; ++j){
                   item = new QTableWidgetItem ;

                    item->setText(query.value(j).toString()) ;

                    qDebug() << item->text() ;
                   ui->listInteraction->setItem(i, j , item) ;
                }
                i++;
            }
        }
    }
    db.close() ;
}

/** Récupération de l'id
 * @brief ListInteractionDialog::setId
 * @param i
 */
void ListInteractionDialog::setId(const QString &i)
{
    idC = i;
}

/** Fermer la fenetre
 * @brief ListInteractionDialog::on_bClose_clicked
 */
void ListInteractionDialog::on_bClose_clicked()
{
    close();
}

