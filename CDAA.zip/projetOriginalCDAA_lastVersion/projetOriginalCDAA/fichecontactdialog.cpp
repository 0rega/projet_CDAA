#include "fichecontactdialog.h"
#include "ui_fichecontactdialog.h"

FicheContactDialog::FicheContactDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::FicheContactDialog)
{
    dbPath = "C:/Users/bello/Downloads/projetOriginalCDAA_lastVersion/projetOriginalCDAA/base.sqlite";
    ui->setupUi(this);

    id = "";

}

FicheContactDialog::~FicheContactDialog()
{
    delete ui;
}

/** Récupération des infos en cas de modification
 * @brief FicheContactDialog::setInfos
 * @param c
 * @param i
 */
void FicheContactDialog::setInfos(const Contact &c, const QString &i)
{
    ui->tbNom->setText(QString::fromStdString(c.getNom()));
    ui->tbPrenom->setText(QString::fromStdString(c.getPrenom()));
    ui->tbEntreprise->setText(QString::fromStdString(c.getEntreprise()));
    ui->tbEmail->setText(QString::fromStdString(c.getMail()));
    list<unsigned int> tel = c.getTelephone();
    for (auto const& i : tel) {
        ui->tbTel->setText(QString::number(i));
    }

    id = i;

}
/** Ajout ou Modification
 * @brief FicheContactDialog::on_bValidate_clicked
 */


void extraction_tags(QString s , QString  *dates, QString *contenus){
    string n = s.toStdString() ;
    istringstream ss(n) ;
    string date, contenu ;
    int comptetodo = 0 , comptedate = 0 ;

    do{
        string subs ;
        ss >> subs;
        if(comptetodo){
            contenu = subs ;
            comptetodo = 0 ;
        }
        if(comptedate){
            comptedate = 0 ;
            date = subs ;
        }
        if(subs == "@todo"){
            comptetodo = 1 ;
        }
        if(subs == "@date"){
            comptedate = 1 ;
        }
    }while(ss) ;

    *dates = QString::fromStdString(date) ;
    *contenus = QString::fromStdString(contenu) ;
}


void FicheContactDialog::on_bValidate_clicked()
{
    db = QSqlDatabase::addDatabase("QSQLITE") ;
        QSqlQuery query , query2;
        QString contenuinteraction ;
        QString dateinteraction ;

        //qDebug() << f ;
        if(id.isEmpty()){
        qDebug() << "ajout BD" ;
        db.setDatabaseName(dbPath) ;
        if(!db.open()){
            qDebug() << "Pas de connexion  à la BDD"  ;
        }
        else{
               qDebug() <<"Connexion BDD ok ! " ;
               string s ;
               time_t timestamp = time( NULL );
               struct tm * nsx = localtime( & timestamp );
               extraction_tags(ui->tbInteraction->text() , &dateinteraction , &contenuinteraction );

               query.prepare("INSERT INTO Contact (Nom, Prenom ,Entreprise, Mail, Telephone , Interaction , photo,  Date_de_creation , Interaction , Todo )"
                             "VALUES (?, ?, ?, ?, ? , ? , ?, ? , ?, ?)");
               query.addBindValue(ui->tbNom->text());
               query.addBindValue(ui->tbPrenom->text());
               query.addBindValue(ui->tbEntreprise->text());
               query.addBindValue(ui->tbEmail->text()) ;
               query.addBindValue(ui->tbTel->text()) ;
               query.addBindValue(ui->tbInteraction->text()) ;
               query.addBindValue(plocate) ;
               s = to_string(nsx->tm_mday) + "/" + to_string(nsx->tm_mon+1) + "/" + to_string(nsx->tm_year+1900) + " " +to_string(nsx->tm_hour) + ":" + to_string(nsx->tm_min) + ":" + to_string(nsx->tm_sec ) ;
               QString x = QString::fromStdString(s) ;
               query.addBindValue(x);
               query.addBindValue(ui->tbInteraction->text()) ;
               query.addBindValue(contenuinteraction) ;
               if(!query.exec()){
                   qDebug() << "Impossible d'executer la requête" ;

               }
               else{
                   qDebug() << "Requete OK" ;
                   qDebug() << "Ajout reussit" ;

                   query2.prepare("INSERT INTO Interaction (Contenu , Date)"
                                  "VALUES (?,?)");
                   query2.addBindValue(dateinteraction) ;
                   query2.addBindValue(contenuinteraction) ;
                   if(!query2.exec()){
                       qDebug() << "requete non valable" ;
                   }
                   else{
                       qDebug() << "Requete Ok" ;
                       qDebug() << "Interaction" ;
                   }
               }
            }
        db.close() ;
        this->close();
       }
        else{
            qDebug() << "Modif BD" ;
            db.setDatabaseName(dbPath) ;
            if(!db.open()) {
                qDebug() << "Pas de connexion à la BDD" ;
            }
            else
            {
                QString contenuinteraction ;
                QString dateinteraction ;
                string s ;
                time_t timestamp = time( NULL );
                struct tm * nsx = localtime( & timestamp );
                extraction_tags(ui->tbInteraction->text() , &dateinteraction , &contenuinteraction );
                qDebug() << "Connexion à la BDD ok ! " ;
                query.prepare("UPDATE Contact set Nom = ? , Prenom = ? , Entreprise = ? , Mail = ? , Telephone = ? , Interaction = ? , Photo = ? ,date_de_creation = ? where idContact = ?") ;
                query.addBindValue(ui->tbNom->text()) ;
                query.addBindValue(ui->tbPrenom->text()) ;
                query.addBindValue(ui->tbEntreprise->text()) ;
                query.addBindValue(ui->tbEmail->text()) ;
                query.addBindValue(ui->tbTel->text().toInt()) ;
                query.addBindValue(ui->tbInteraction->text()) ;
                query.addBindValue(plocate) ;
                s = to_string(nsx->tm_mday) + "/" + to_string(nsx->tm_mon+1) + "/" + to_string(nsx->tm_year+1900) + " " +to_string(nsx->tm_hour) + ":" + to_string(nsx->tm_min) + ":" + to_string(nsx->tm_sec ) ;
                QString x = QString::fromStdString(s) ;
                query.addBindValue(x);
                query.addBindValue(id) ;
                if(!query.exec()){
                    qDebug() << "Erreur de requete dans la base de donnée " ;
                }
                else{
                    qDebug() << "Requete OK" ;
                    qDebug() << "Modification reussit " ;
                }

            }
            db.close() ;
            this->close() ;
        }
}

/** Fermer la fenetre
 * @brief FicheContactDialog::on_bCanceled_clicked
 */


void FicheContactDialog::on_bAjout_photo_clicked() {
    qDebug()  << "Ajout de photo" ;

        QString filename = QFileDialog::getOpenFileName(this , tr("Choisir") , "" , tr("Images(*.png *.jpg *.jpeg *.bmp *.gif)")) ;
        if(QString::compare(filename, QString()) != 0){
            QImage image ;
            bool valide = image.load(filename) ;
            if(valide){
                image = image.scaledToWidth(100 , Qt::SmoothTransformation);
                ui->lbAffichePhoto->setPixmap(QPixmap::fromImage(image)) ;
            }
            else{
                // erreur de la mise en photo ;
            }

        }
        plocate = filename ;

}

void FicheContactDialog::on_bCanceled_clicked()
{
    close();
}



void FicheContactDialog::on_tbTel_textChanged(const QString &arg1)
{
    /**Vérification du type entrée /!\ NOMBRE UNIQUEMENT /!\**/
}

