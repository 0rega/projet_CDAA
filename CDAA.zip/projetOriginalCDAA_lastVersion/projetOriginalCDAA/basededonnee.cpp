#include "basededonnee.h"

BaseDeDonnee::BaseDeDonnee(QObject *parent) : QObject(parent)
{
    dbPath = "C:/Users/bello/Downloads/projetOriginalCDAA_lastVersion/projetOriginalCDAA/base.sqlite" ;
}

/** Connexion et création de la base de données
 * @brief BaseDeDonnee::connexionBDD
 */
void BaseDeDonnee::connexionBDD(){

    db = QSqlDatabase::addDatabase("QSQLITE")  ;
    db.setDatabaseName("base.sqlite")  ;
    QSqlQuery query, query2 ;



    if(!db.open()){
        qDebug() << "Pas de Connexion BDD" ;
    }
    else{
        qDebug() << "Connexion BDD ok" ;
        query.prepare("CREATE TABLE IF NOT EXIST Contact (idContact INTEGER NOT NULL PRIMARY KEY , Nom varchar(20) , prenom varchar(20) , entreprise varchar(20) , mail varchar(20), telephone integer , uriPhoto varchar(20), interactions varchar(50) , todo varchar(50)") ;
        if(!query.exec()){
            qDebug() << "Impossible d'executer la requete" ;
        }
        else{
            qDebug() << "Requete Ok !" ;
            qDebug() << "Base de donnée créer" ;

        }
    }
}

/** Suppression d'un contact grace à l'id
 * @brief BaseDeDonnee::deleteContact
 * @param id
 */
void BaseDeDonnee::deleteContact(const QString &id)
{
    qDebug() << id ;

    db = QSqlDatabase::addDatabase("QSQLITE") ;
    db.setDatabaseName(dbPath) ;

    QSqlQuery query ;


    if(!db.open()){
        qDebug() << "Pas de connexion  à la BDD" ;
    }
    else {
        qDebug() << "Connexion à la BDD";
        query.prepare("delete from Contact where idContact = ? or nom = ? or prenom = ? or entreprise = ? or mail = ? or photo = ? or date_de_creation = ? or telephone = ? or interaction = ? or todo = ? ");
        query.addBindValue(id);
        query.addBindValue(id);
        query.addBindValue(id);
        query.addBindValue(id);
        query.addBindValue(id);
        query.addBindValue(id);
        query.addBindValue(id);
        query.addBindValue(id);
        query.addBindValue(id);
        query.addBindValue(id);
        if (!query.exec()) {
            qDebug() << "La requete ne s'execute pas sur la base de donnée :(";
        } else {
            qDebug() << "Requete reussit dans la base de donnée";
        }

    }
    db.close() ;

}
