#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    dbPath = "C:/Users/bello/Downloads/projetOriginalCDAA_lastVersion/projetOriginalCDAA/base.sqlite";
    ui->setupUi(this);
    affiche_BD() ;

    ui->bModifier->setVisible(false);
    ui->bSupprimer->setVisible(false);
}

/** Permet l'affichage et l'actualisation de la liste des contacts
 * @brief MainWindow::affiche_BD
 */
void MainWindow::affiche_BD(){
    ui->ListContacts->setRowCount(0);
    db = QSqlDatabase::addDatabase("QSQLITE") ;
    db.setDatabaseName(dbPath) ;
    int i = 0;
    QSqlQuery query ;
    if(!db.open()){
        qDebug() << "Impossible de la connexion de la base de donnée "  ;
    }
    else{
        qDebug() << "Connexion ok  de la BDD" ;
        query.prepare("SELECT * FROM Contact") ;
        if(!query.exec()){
            qDebug() << "Impossible d'executer la requete " ;
        }
        else{
            QString s ;
            qDebug() << "Requete reussit" ;
            //qDebug()<< i ;

            //qDebug() << nbrow ;
            int nbcol = 10 ;
            //ui->ListContacts->setRowCount(nbrow) ;
            ui->ListContacts->setColumnCount(nbcol) ;
            QStringList hlabels ;
            hlabels << "idContact" << "Nom" << "Prenom" << "Entreprise" << "Email" << "Photo" << "Telephone" << "Date de creation" << "Interaction"  << "Todo"  ;
            ui->ListContacts->setHorizontalHeaderLabels(hlabels);

            while(query.next()){
                ui->ListContacts->insertRow( ui->ListContacts->rowCount() );
                QTableWidgetItem *item ;
                for(int j = 0 ; j < nbcol ; ++j){
                   item = new QTableWidgetItem ;

                    item->setText(query.value(j).toString()) ;

                    qDebug() << item->text() ;
                   ui->ListContacts->setItem(i, j , item) ;

                }
                i++;
            }
        }
    }
    this->setNbContacts(i);
    db.close() ;
}

/** Cache les boutons modifier et supp quand aucun contact n'est sélectionné
 * @brief MainWindow::cacherBouton
 */
void MainWindow::cacherBouton()
{
    ui->bModifier->setVisible(false);
    ui->bSupprimer->setVisible(false);
}

/*fonction d'ajout dans la BD*/
/*
void extraction_tags(QString s , QString  *dates, QString *contenus){
    string n = s.toStdString() ;
    istringstream ss(n) ;
    string date, contenu ;
    int comptetodo = 0 , comptedate = 0 ;

    do{
        string subs ;
        ss >> subs;
        if(comptetodo){
            contenu = subs ;
            comptetodo = 0 ;
        }
        if(comptedate){
            comptedate = 0 ;
            date = subs ;
        }
        if(subs == "@todo"){
            comptetodo = 1 ;
        }
        if(subs == "@date"){
            comptedate = 1 ;
        }
    }while(ss) ;

    *dates = QString::fromStdString(date) ;
    *contenus = QString::fromStdString(contenu) ;
}*/

/*Ajout de la photo*/
void MainWindow::ajouter_UP(){
  qDebug()  << "Ajout de photo" ;

  QString filename = QFileDialog::getOpenFileName(this , tr("Choisir") , "" , tr("Images(*.png *.jpg *.jpeg *.bmp *.gif)")) ;
  if(QString::compare(filename, QString()) != 0){
      QImage image ;
      bool valide = image.load(filename) ;
      if(valide){
          image = image.scaledToWidth(50 , Qt::SmoothTransformation);
          lphoto->setPixmap(QPixmap::fromImage(image)) ;
      }
      else{
          // erreur de la mise en photo ;
      }

  }
    plocate = filename ;
}

void MainWindow::show_in_list(GestionContact &l){
    QString s;
    string sx ;
    for(auto &v:l.getListContact()){
        sx+=v.getNom()+" "+v.getPrenom()+" "+v.getEntreprise()+" "+v.getMail() + " " + v.getUriPhoto() ;
    }
    s = QString::fromStdString(sx) ;
    emit listqstring(s) ;
}

void MainWindow::decision(bool &d){
    dec = d  ;
}

void MainWindow::ls(int &l){
    ligne_selectionner = l ;
}

void MainWindow::char_dec(bool&b){
    value = b  ;
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::setNbContacts(const int &nb)
{
    ui->tbNbContacts->setText(QString::number(nb));
}


void MainWindow::qstringid(QString &id) {
    idx = id ;
}

/** Barre de recherche
 * @brief MainWindow::on_bRecherche_clicked
 */

void MainWindow::on_bExportJSON_clicked(){
    QJsonDocument  json;
    QJsonArray recordsArray;
    QJsonObject  recordObject;

    for(int i = 0 ; i < ui->ListContacts->rowCount() ; ++i){
        for(int j = 0 ; j < ui->ListContacts->columnCount() ; ++j){
            switch(j){
            case 0:
                recordObject.insert("idContact", QJsonValue::fromVariant(ui->ListContacts->item(i, j)->text()));
                break ;
            case 1:
                recordObject.insert("Nom", QJsonValue::fromVariant(ui->ListContacts->item(i, j)->text()));
                break ;
            case 2:
                recordObject.insert("Prenom", QJsonValue::fromVariant(ui->ListContacts->item(i, j)->text()));
                break ;
            case 3:
                recordObject.insert("Entreprise", QJsonValue::fromVariant(ui->ListContacts->item(i, j)->text()));
                break;
            case 4:
                recordObject.insert("Mail", QJsonValue::fromVariant(ui->ListContacts->item(i, j)->text()));
                break ;
            case 5:
                recordObject.insert("Photo", QJsonValue::fromVariant(ui->ListContacts->item(i, j)->text()));
                break ;
            case 6:
                recordObject.insert("Telephone", QJsonValue::fromVariant(ui->ListContacts->item(i, j)->text()));
                break ;
            case 7:
                recordObject.insert("Date de creation", QJsonValue::fromVariant(ui->ListContacts->item(i, j)->text()));
                break ;
            case 8:
                recordObject.insert("Interaction", QJsonValue::fromVariant(ui->ListContacts->item(i, j)->text()));
                break ;
             case 9:
                recordObject.insert("Todo", QJsonValue::fromVariant(ui->ListContacts->item(i, j)->text()));
                break ;
            default:
                break ;
            }
        }
    }
    recordsArray.push_back(recordObject) ;
    json.setArray(recordsArray) ;
    qDebug() << json ;
}

void MainWindow::on_bRecherche_clicked()
{
    QString s = ui->tbRecherche->text() ;

    if(s.isEmpty())
    {
        this->affiche_BD();
    }
    else
    {
        db = QSqlDatabase::addDatabase("QSQLITE") ;
        QSqlQuery query ;
        db.setDatabaseName(dbPath) ;
        if(!db.open()){
            qDebug() << "Pas de connexion à la BDD"  ;
        }
        else{
            qDebug() << "Connexion à la BDD ok" ;
            query.prepare("SELECT * from Contact where nom = ? or prenom = ? or entreprise = ? or date_de_creation = ? or mail = ? or photo = ? or telephone = ? or interaction = ? ") ;
            query.addBindValue(ui->tbRecherche->text()) ;
            query.addBindValue(ui->tbRecherche->text()) ;
            query.addBindValue(ui->tbRecherche->text()) ;
            query.addBindValue(ui->tbRecherche->text()) ;
            query.addBindValue(ui->tbRecherche->text()) ;
            query.addBindValue(ui->tbRecherche->text()) ;
            query.addBindValue(ui->tbRecherche->text()) ;
            query.addBindValue(ui->tbRecherche->text()) ;
            if(!query.exec()){
                qDebug() << "Impossible d'executer la requete" ;
            }
            else{

                int nbcol = 10 ;

                ui->ListContacts->setColumnCount(nbcol) ;
                QStringList hlabels ;
                hlabels << "idContact" << "Nom" << "Prenom" << "Entreprise" << "Email" << "Photo" << "Telephone" << "Date de creation" << "Interaction"  << "Todo"  ;
                ui->ListContacts->setHorizontalHeaderLabels(hlabels);
                qDebug() << "Recherche effectuer" ;
                int i = 0;
                ui->ListContacts->setRowCount(0);
                while(query.next()){
                    ui->ListContacts->insertRow( ui->ListContacts->rowCount() );
                    QTableWidgetItem *item ;
                    for(int j = 0 ; j < nbcol ; ++j){
                       item = new QTableWidgetItem ;

                        item->setText(query.value(j).toString()) ;

                        qDebug() << item->text() ;
                       ui->ListContacts->setItem(i, j , item) ;

                    }
                    i++;
                }
            }
        }
    }
}

/**Modification d'un contact
 * @brief MainWindow::on_bModifier_clicked
 */

void MainWindow::on_bInteraction_clicked(){
    linter = new ListInteractionDialog() ;
    linter->show() ;
    linter->afficheInteraction() ;
}

void MainWindow::on_bModifier_clicked()
{
    //On récupère les informations déjà existantes
    Contact c;
    int row = ui->ListContacts->currentRow();
    QString id = ui->ListContacts->item(row, 0)->text();
    c.setNom(ui->ListContacts->item(row, 1)->text().toStdString());
    c.setPrenom(ui->ListContacts->item(row, 2)->text().toStdString());
    c.setEntreprise(ui->ListContacts->item(row, 3)->text().toStdString());
    c.setMail(ui->ListContacts->item(row, 4)->text().toStdString());
    c.addTelephone(ui->ListContacts->item(row, 6)->text().toInt());

    //Création de la nouvelle fenetre
    fcd = new FicheContactDialog();
    fcd->setInfos(c, id);
    fcd->show();

    //Lorsque la fentre est fermée, on actualise la liste et on recache les boutons
    if(fcd->exec() == 0)
    {
        this->affiche_BD();
        this->cacherBouton();
    }

}

/** Supprime un contact
 * @brief MainWindow::on_bSupprimer_clicked
 */
void MainWindow::on_bSupprimer_clicked()
{
    int row = ui->ListContacts->currentRow();
    int column = ui->ListContacts->currentColumn();

    QString id = ui->ListContacts->item(row, column)->text();

        //qDebug() << id << endl;
    QMessageBox msgBox;
    msgBox.setText("Voulez-vous supprimer ce contact ?");
    msgBox.setWindowTitle("Confirmation de la suppression");
    msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::Cancel);
    int ret = msgBox.exec();

    if(ret == QMessageBox::Yes)
    {
        dbx.deleteContact(id);
        this->affiche_BD();
    }
    else
    {
        msgBox.close();
    }

}


/** Bouton ajouter un contact
 * @brief MainWindow::on_bAjouter_clicked
 */
void MainWindow::on_bAjouter_clicked()
{
    fcd = new FicheContactDialog();
    fcd->show();

    if(fcd->exec() == 0)
    {
        this->affiche_BD();
        this->cacherBouton();
    }

}

/** Sélection d'une cellule dans la tableau de contact
 * @brief MainWindow::on_ListContacts_cellClicked
 * @param row
 * @param column
 */
void MainWindow::on_ListContacts_cellClicked(int row, int column)
{
    ui->bModifier->setVisible(true);
    ui->bSupprimer->setVisible(true);
}

